(function(b,e){const r=S,x=b();for(;;)try{if(-parseInt(r(161))/1+parseInt(r(360))/2+-parseInt(r(194))/3*(parseInt(r(282))/4)+parseInt(r(216))/5*(-parseInt(r(236))/6)+-parseInt(r(141))/7+-parseInt(r(356))/8+parseInt(r(268))/9===e)break;x.push(x.shift())}catch{x.push(x.shift())}})(xe,569888);function S(b,e){const r=xe();return S=function(x,C){return x=x-138,r[x]},S(b,e)}function xe(){const b=["504_bank_loan_2_amortization","504_bank_2_fee_rate_b","destroy","disabled","Analytics","#nav_table","#result504_2_agg_total_interest","#fafafa","#result504_2_fees_c","bar","2.25 %","transform","#504_bank_2_fee_rate_a","dp504_amt","POST","504_bank_loan_2_amount","#schedule_wrapper","5 %","3000","isArray","host","0.95rem","pageInfo_","#222","504_bank_2_fees_d","7a_bank_loan_per","collapse","#purchase_price_info","#F0EBCE","504_bank_2_fee_rate_a","10px 16px","Per.","504_bank_2_fees_b","font","charAt","undefined","#000","options","View","#table_view_btn_2_agg","3 %","bl2_amt","Table","centerTextPlugin","warn","justifyContent","#504_bank_loan_2_rate","Paid_Principle","loan_amount_7a_agg","No table data.","10000","Total Percentage should be equal to 100%","0.75 %","#table_view_btn_1_agg","result504_1_agg","#bfafe3","smooth","min","LastMonthOfYearData504_2","textContent","reduce","504_bank_loan_2_term","legend-label","#toggle-input","replace","#d6d99e","504_down_payment_amount","legend-item","option","Payment_Number","2 %","504_bank_loan_1_amount","3.25 %","504_bank_1_fees","_agg","result","json","startsWith","#504_bank_loan_2_per","-2 %","1.75 %","split","bl1_amt","#153462","7a_prime_3yr_term_per","labels","color"," of ","total_interest","cursor","target","observe","#result504_2_agg_monthly","keys","40 %","push","white","--activeBtn","70%","change","7a_down_payment_per","45 %","trim","innerHTML","Amorization_504_1","#_pie_chart","504_down_payment_per","middle","dp504_per","querySelector","display","purchase_price","85 %","replaceAll","6558790NpPCjg","5000","Total Interest Paid","#504_bank_2_fee_rate_b","dataset","0 %","start","datasets","term_7a","slice","submit","result504_2","hasError","center","504_bank_loan_1_per","characterPlacement","Term","3.75 %","save","createElement","493432fDWcYD","20px 10px","Total Percentage should be equal to 100% and Bank Loan 1 percentage should be more than Bank loan 2 percentage","rate_504_2","rgba(0,0,0,0.05)","className","0.50 %","#field_504_bl1","#32326926 0 2px 5px","7a_bank_loan_amount","1px solid #eee","100%","result504_1","doughnut","#alert_504_down_payment_per","0.25 %","504_bank_2_fee_rate_c","Graph","loan_amount_504_2_agg","style","35 %","2.75 %","value","https://services.simplifyingcalculation.com/api/7A504Calculator/?license_key=","result504_2_agg","view_title","#result504_1_total_interest","some","specialCharacter","7a_fees","12px 18px","20 %","504_bank_2_fees_c","2955963wnGGdB","translateX(0) scale(1)","rate_7a","rgba(17, 17, 26, 0.1) 0px 4px 16px","then","#amort-table-footer","--error","#504_bank_loan_1_term","includes","#nav_graph","backgroundColor","appendChild","1.50 %","#field_504_down","bl2_fee_rate_c","alignItems","length","2.50 %","#chartContainer","bl1_fees","Per","background","3740705QuxFnr","object","#amort-table","Down Payment","Rows per page: ","bottom","select","Submit","25 %","-1 %","65 %","thead","floor","log","none","#504_bank_2_fees_d","30 %","3500","term_504_1","getAttribute","6ANTBTa","Amount","flex","transition","1 %","#504_bank_2_fee_rate_c","application/json","down_payment_504_1","getElementById","label","0.40 %","textAlign","selected","--disabled","Submitting...","join","raw","error","button","addEventListener","doughnutChart","max","mortgage_expense","700 ","padding","flex-end","#view_area_wrapper","504_bank_2_fees_a","Paid_Interest","rate_504_1","8px 0","#view_title","37896417uQHbzd","loan_amount_7a","top","type","#purchase_price","#37a1de"," Table","required","7a_down_payment_amount","parentElement","loan_amount_504_1_agg","INPUT","bl2_fee_rate_b","isRequired","4RFGYEt",": $ ","text","70 %","opacity","loan_amount_504_2","black","doughLegend","block","centerColor","bl2_per","Rate","Loan 1","term_504_2","#manufacturer-content","#tableContainer","504_bank_loan_1_amortization","showCenterValue","20px","1.25 %","#504_bank_loan_1_rate","#504_bank_loan_2_term","preventDefault","Amorization_504_2","classList","test","#amort-table-container","span","borderBottom","#ccc","fillStyle","monthly_payment","transparent","calculated_data","#table_view_btn_2","marginTop","down_payment_504_2","Remaining_Balance","#table_view_btn_1","search","15 %","stringify","7500","#504_bank_2_fees_d_input","left","legendElementId","div","boxShadow","Active","#result504_1_monthly","504_bank_loan_2_rate","#result504_2_fees_a","data","right","loan_amount_504_1","isIntersecting","$doughOpts","bl1_fee_rate","7a_bank_loan_amortization","transform 0.8s ease, opacity 0.8s ease","rgba(0, 0, 0, 0.2)","75 %","input","Monthly Payment","#504_down_payment_per","stackedChart2","pointer","#year_list","504_bank_loan_2_per","toFixed","7a_fees_rate","8px","Amortization","504_bank_loan_1_rate","5262184UuEBuP","marginRight","amortization_table","map","361624NPdLZA","#1a2980","504_bank_1_fee_rate","10 %","result_container","find","#504_bank_loan_1_per","register","bl1_per","Chart.js not loaded","#field_504_bl2","findIndex","Loan 2","no_dollar","rows-per-page-group","assign","amort-nav-group","bl2_fees_c","4 %","forEach","key","click"];return xe=function(){return b},xe()}function Ne(b){const e=S,r=(a,t=b)=>{const n=S;return typeof a=="string"&&a[n(459)]("#")?t.getElementById(a[n(150)](1)):t[n(491)](a)};function x(a){const t=S,n=b[t(244)](a);n&&n.scrollIntoView({behavior:t(438),block:t(147)})}function C(a){const t=S;return a==null?!0:Array[t(401)](a)?a.length===0:typeof a===t(217)?Object[t(475)](a)[t(210)]===0:!1}function v(a){const t=S;if(a==null||a==="")return"";const n=String(a)[t(446)](/[^0-9.-]/g,"");if(n===""||isNaN(Number(n)))return a;const[o,i]=n[t(463)]("."),l=o[t(446)](/\B(?=(\d{3})+(?!\d))/g,",");return i!==void 0?l+"."+i:l}function R(a){const t=S;return String(a??"")[t(140)](",","")}function W(a,t){const n=S;return String(t??"")[n(463)](a)[n(251)]("")}function J(a){const t=S;return a?/^(\d+(\.\d*)?|\.\d+)$/[t(307)](R(a)):!1}function O(a){const t=S;if(a==null)return"";let n=String(a);return n=W("$",n),n=W("%",n),n=R(n),n=n[t(446)](/\D/g,""),n.trim()}function j(a,t){const n=parseFloat(a)||0,o=parseFloat(t)||0;return n*o/100}function ae(a){const t=S;return a==null?0:Number(String(a)[t(140)]("$","").replaceAll(",",""))||0}let g=[{type:e(284),name:"Amount",label:"",id:"purchase_price",key:e(138),value:1e6,hasError:!1,errorCount:0,errorMessage:"Purchase Price cannot be more than 5 Million",disabled:!1,isRequired:!1},{type:e(222),name:e(413),label:e(413),id:"7a_down_payment_per",key:e(482),options:[{label:"5 %",value:5},{label:"10 %",value:10},{label:e(322),value:15},{label:e(192),value:20},{label:e(224),value:25},{label:e(232),value:30},{label:"35 %",value:35}],value:10,hasError:!1,errorCount:0,errorMessage:e(433),disabled:!1,isRequired:!1},{type:e(284),name:e(237),label:e(237),id:e(276),key:"down_payment_7a",value:1e5,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:e(222),name:"Per.",label:e(413),id:"7a_bank_loan_per",key:e(407),options:[{label:e(226),value:65},{label:e(285),value:70},{label:e(343),value:75},{label:"80 %",value:80},{label:e(139),value:85},{label:"90 %",value:90},{label:"95 %",value:95}],value:90,hasError:!1,errorCount:0,errorMessage:e(433),disabled:!1,isRequired:!1},{type:e(284),name:e(237),label:e(237),id:e(170),key:e(269),value:9e5,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:e(222),name:"Amortization",label:e(354),id:e(340),key:"Amorization7a",options:[{label:"15",value:15},{label:"20",value:20},{label:"25",value:25}],value:20,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(222),name:e(293),label:"",id:e(466),key:e(196),options:[{label:"-2 %",value:-2},{label:e(225),value:-1},{label:e(146),value:0},{label:e(240),value:1},{label:e(452),value:2},{label:e(422),value:3},{label:e(378),value:4},{label:e(399),value:5}],value:2,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:"select",name:"Term",label:"",id:"7a_prime_5yr_term_per",key:e(196),options:[{label:e(461),value:-2},{label:e(225),value:-1},{label:e(146),value:0},{label:e(240),value:1},{label:e(452),value:2},{label:e(422),value:3},{label:e(378),value:4},{label:e(399),value:5}],value:3,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:"text",name:e(413),label:e(413),id:"7a_fees_rate",key:e(352),value:3.5,options:[{label:"0",value:0},{label:e(176),value:.25},{label:"0.50 %",value:.5},{label:e(434),value:.75},{label:e(240),value:1},{label:e(301),value:1.25},{label:e(206),value:1.5},{label:e(462),value:1.75},{label:e(452),value:2},{label:e(392),value:2.25},{label:e(211),value:2.5},{label:e(182),value:2.75},{label:e(422),value:3},{label:e(454),value:3.25},{label:"3.50 %",value:3.5},{label:e(158),value:3.75}],hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:"Amount",label:e(237),id:"7a_fees",key:e(190),value:31500,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:e(222),name:e(413),label:e(413),id:e(488),key:e(488),options:[{label:"5 %",value:5},{label:e(363),value:10},{label:"15 %",value:15},{label:e(192),value:20},{label:"25 %",value:25},{label:e(232),value:30},{label:e(181),value:35}],value:10,hasError:!1,errorCount:0,errorMessage:e(433),disabled:!1,isRequired:!1},{type:e(284),name:e(237),label:"Amount",id:e(448),key:"down_payment_504_1",value:1e5,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:e(222),name:e(413),label:e(413),id:e(155),key:"504_bank_loan_1_per",options:[{label:e(224),value:25},{label:e(232),value:30},{label:e(181),value:35},{label:"40 %",value:40},{label:e(483),value:45},{label:"50 %",value:50}],value:50,hasError:!1,errorCount:0,errorMessage:e(163),disabled:!1,isRequired:!1},{type:e(284),name:e(237),label:e(237),id:e(453),key:e(336),value:5e5,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:"select",name:e(157),label:e(157),id:"504_bank_loan_1_term",key:e(234),options:[{label:"5",value:5},{label:"7",value:7},{label:"10",value:10}],value:7,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(222),name:e(354),label:e(354),id:e(298),key:e(486),options:[{label:"20",value:20},{label:"25",value:25}],value:25,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:e(293),label:e(293),id:e(355),key:e(265),value:6,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:e(237),label:e(237),id:e(455),key:e(455),value:1250,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:e(222),name:e(413),label:e(413),id:e(362),key:"504_bank_1_fee_rate",options:[{label:"0",value:0},{label:e(176),value:.25},{label:e(167),value:.5},{label:"0.75 %",value:.75},{label:e(240),value:1},{label:e(301),value:1.25},{label:"1.50 %",value:1.5},{label:e(462),value:1.75},{label:"2 %",value:2}],value:1,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(222),name:e(413),label:e(413),id:e(350),key:e(350),options:[{label:"20 %",value:20},{label:e(224),value:25},{label:e(232),value:30},{label:e(181),value:35},{label:e(476),value:40}],value:40,hasError:!1,errorCount:0,errorMessage:e(163),disabled:!1,isRequired:!1},{type:e(284),name:e(237),label:"Amount",id:e(397),key:e(287),value:4e5,hasError:!1,errorCount:0,errorMessage:"",disabled:!0,isRequired:!1},{type:e(222),name:"Term",label:"Term",id:"504_bank_loan_2_term",key:e(295),options:[{label:"10",value:10},{label:"15",value:15},{label:"20",value:20},{label:"25",value:25}],value:5,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(222),name:"Amortization",label:e(354),id:e(382),key:e(305),options:[{label:"15",value:15},{label:"20",value:20},{label:"25",value:25}],value:20,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:"Rate",label:e(293),id:e(332),key:e(164),value:6,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:"Per",label:e(214),id:"504_bank_2_fee_rate_a",key:e(411),options:[{label:"1.5%",value:1.5},{label:e(176),value:.25},{label:"0.40 %",value:.4},{label:"0.75 %",value:.75},{label:e(240),value:1},{label:e(301),value:1.25},{label:e(206),value:1.5},{label:e(462),value:1.75},{label:e(452),value:2}],value:1.5,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:e(214),label:e(214),id:e(383),key:e(383),options:[{label:"0",value:0},{label:e(176),value:.25},{label:e(246),value:.4},{label:e(434),value:.75},{label:e(240),value:1},{label:e(301),value:1.25},{label:e(206),value:1.5},{label:e(462),value:1.75},{label:e(452),value:2}],value:.4,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:"select",name:"Per",label:e(214),id:e(177),key:e(177),options:[{label:"0",value:0},{label:"0.25 %",value:.25},{label:"0.50 %",value:.5},{label:"0.75 %",value:.75},{label:e(240),value:1},{label:e(301),value:1.25},{label:e(206),value:1.5},{label:e(462),value:1.75},{label:"2 %",value:2}],value:.25,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:"select",name:"Amount",label:e(237),id:e(406),key:"504_bank_2_fees_d",options:[{label:"2500",value:2500},{label:e(400),value:3e3},{label:e(233),value:3500},{label:e(142),value:5e3},{label:e(324),value:7500},{label:e(432),value:1e4}],value:5e3,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:"Amount",label:e(237),id:e(263),key:"504_bank_2_fees_a",value:2e3,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:"text",name:e(237),label:"Amount",id:"504_bank_2_fees_b",key:e(414),value:6e3,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1},{type:e(284),name:"Amount",label:e(237),id:"504_bank_2_fees_c",key:e(193),options:[{label:"2500",value:2500},{label:e(400),value:3e3},{label:"3500",value:3500},{label:"5000",value:5e3},{label:e(324),value:7500},{label:e(432),value:1e4}],value:3500,hasError:!1,errorCount:0,errorMessage:"",disabled:!1,isRequired:!1}],c={},Q=e(173),ce="Table",be=!1,qe=e(223);const I=r("#submit_button"),d={purchase_price:()=>A("purchase_price"),dp504_per:()=>A(e(488)),dp504_amt:()=>A(e(448)),bl1_per:()=>A(e(155)),bl1_amt:()=>A("504_bank_loan_1_amount"),bl2_per:()=>A(e(350)),bl2_amt:()=>A("504_bank_loan_2_amount"),bl1_fee_rate:()=>A(e(362)),bl1_fees:()=>A(e(455)),bl2_fee_rate_a:()=>A(e(411)),bl2_fees_a:()=>A(e(263)),bl2_fee_rate_b:()=>A("504_bank_2_fee_rate_b"),bl2_fees_b:()=>A(e(414)),bl2_fee_rate_c:()=>A(e(177)),bl2_fees_c:()=>A(e(193)),bl2_fees_d:()=>A(e(406))};function A(a){return g.findIndex(t=>t.id===a)}function m(a){return g[A(a)]||{}}function Ce(a,t){const n=e,o=A(a);o>=0&&(g[o][n(183)]=t)}function Ee(){const a=e,t=r(a(175)),n=r("#alert_504_bank_loan_1_per"),o=r("#alert_504_bank_loan_2_per"),i=m(a(488)),l=m("504_bank_loan_1_per"),_=m("504_bank_loan_2_per");t[a(441)]=i.hasError?"⚠️":"",n[a(441)]=l.hasError?"⚠️":"",o[a(441)]=_[a(153)]?"⚠️":"",pe(a(207),i[a(153)]),pe(a(168),l[a(153)]),pe(a(370),_[a(153)])}function pe(a,t){const n=e,o=r(a);o&&o[n(306)].toggle(n(200),!!t)}function me(){const a=e;return(parseFloat(O(r(a(272))[a(183)]))||0)>=1e7}function Pe(a,t){const n=e,o=a[n(359)](f=>({...f})),i=o[d[n(490)]()][n(183)],l=o[d[n(368)]()][n(183)],_=o[d.bl2_per()][n(183)],s=Number(i)+Number(l)+Number(_);o[d[n(490)]()][n(153)]=!1,o[d.bl1_per()][n(153)]=!1,o[d.bl2_per()][n(153)]=!1,[100,"100",100][n(202)](s)?Number(l)<Number(_)&&(t===d.bl1_per()&&(o[d[n(368)]()].hasError=!0),t===d.bl2_per()&&(o[d[n(292)]()][n(153)]=!0)):(t===d[n(490)]()&&(o[d.dp504_per()][n(153)]=!0),t===d[n(368)]()&&(o[d[n(368)]()][n(153)]=!0),t===d[n(292)]()&&(o[d[n(292)]()].hasError=!0));const p=o[d.purchase_price()];return p[n(281)]&&(p.value===""||Number(p[n(183)])===0)?p[n(153)]=!0:p.hasError=!1,o}const B=(a,t,n=!1)=>{const o=e,i=b[o(244)](a);!i||!t||(i.tagName===o(279)&&!n?i[o(183)]="$ "+v((t||0).toFixed?t[o(351)](2):t):i[o(183)]=t)};function ue(a,t){const n=e;let o=a.map(l=>({...l}));const i=parseFloat(m(n(138))[n(183)])||0;if(o[d[n(395)]()][n(183)]=j(i,o[d[n(490)]()][n(183)]),o[d[n(464)]()][n(183)]=j(i,o[d[n(368)]()][n(183)]),o[d[n(423)]()][n(183)]=j(i,o[d[n(292)]()].value),me()){const l=be?55e5:5e6;o[d[n(423)]()][n(183)]>=l&&(o[d[n(423)]()][n(183)]=l)}o[d[n(213)]()][n(183)]=j(o[d[n(464)]()][n(183)],o[d[n(339)]()][n(183)]),o[d.bl2_fees_a()][n(183)]=j(o[d[n(423)]()][n(183)],o[d.bl2_fee_rate_a()][n(183)]),o[d.bl2_fees_b()].value=j(o[d[n(423)]()].value,o[d[n(280)]()].value),o[d[n(377)]()][n(183)]=j(o[d[n(423)]()][n(183)],o[d[n(208)]()].value),o=Pe(o,t),g=o,te()}function te(){const a=e,t=r(a(409));t&&(t[a(180)][a(492)]=me()?a(290):a(230)),B("purchase_price",m(a(138)).value),B("504_down_payment_amount",m("504_down_payment_amount")[a(183)]),B(a(453),m(a(453))[a(183)]),B(a(355),m("504_bank_loan_1_rate")[a(183)],a(373)),B(a(397),m("504_bank_loan_2_amount")[a(183)]),B(a(332),m(a(332))[a(183)],a(373)),B(a(455),m("504_bank_1_fees").value),B(a(263),m(a(263))[a(183)]),B(a(414),m(a(414))[a(183)]),B(a(193),m(a(193))[a(183)]);const n=r(a(231)),o=r(a(325));n&&o&&(o[a(183)]="$ "+v(n[a(183)]),Ce("504_bank_2_fees_d",Number(n.value||0))),Ee();const i=g[a(188)](l=>l.hasError)||!(parseFloat(m("purchase_price")[a(183)])>0);I&&(I.disabled=i,I[a(306)].toggle(a(249),i),I[a(441)]=qe)}const ve={labels:[e(219),"Bank Loan 1","Bank Loan 2"],datasets:[{label:"Payment",data:[m(e(448))[e(183)],m("504_bank_loan_1_amount")[e(183)],m(e(397))[e(183)]],backgroundColor:[e(447),e(437),e(273)],cutout:e(480),borderColor:e(314)}]},he={id:e(425),afterDraw(a){var E;const t=e,n=a[t(338)]||{};if(!n[t(299)])return;const{ctx:o,chartArea:i}=a,l=(E=a[t(334)][t(148)])==null?void 0:E[0];if(!l)return;const _=(l[t(334)]||[])[t(359)](u=>Number(u)||0),s=_[t(442)]((u,w)=>u+w,0)||0,p=(i[t(326)]+i[t(335)])/2,f=(i[t(270)]+i[t(221)])/2;o[t(159)](),o[t(247)]=t(154),o.textBaseline=t(489);const y=Math[t(257)](12,Math[t(228)]((i.bottom-i[t(270)])*.08));o[t(415)]=t(259)+y+"px sans-serif",o[t(312)]=n[t(291)]||t(405);const h=n[t(156)]==="end"?v(s[t(351)](0))+" "+(n[t(189)]||"$"):""+(n[t(189)]||"$")+v(s[t(351)](0));o.fillText(h,p,f),o.restore()}};let G=null;function ye(a,t,n={}){const o=e;if(typeof Chart===o(417)){console[o(426)](o(369));return}const i=b[o(244)](a);if(!i)return;const l={showCenterValue:!0,specialCharacter:"$ ",characterPlacement:o(147),centerColor:o(405),displayLegend:!0,legendElementId:o(289)},_=Object[o(375)]({},l,n),s={responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:_.displayLegend,position:"bottom",labels:{usePointStyle:!1}},tooltip:{enabled:!0,callbacks:{label(f){const y=o,h=f[y(252)];return(f[y(245)]||"")+": "+(_[y(189)]||"$ ")+v(Number(h)[y(351)](0))}}}}};if(G){try{G[o(384)]()}catch{}G=null}Chart[o(367)](he),G=new Chart(i.getContext("2d"),{type:o(174),data:t,options:s,plugins:[he]}),G[o(338)]={showCenterValue:_.showCenterValue,specialCharacter:_[o(189)],characterPlacement:_.characterPlacement,centerColor:_[o(291)]};const p=b[o(244)](_[o(327)]);if(p){p[o(485)]="";const f=t[o(467)]||[],y=t[o(148)]&&t[o(148)][0][o(204)]||[];f.forEach((h,E)=>{const u=o,w=document.createElement("div");w[u(166)]=u(449);const M=document[u(160)](u(309));M[u(166)]="legend-swatch",M[u(180)][u(215)]=y[E]||u(311);const k=document[u(160)](u(309));k.className=u(444),k.textContent=h,w[u(205)](M),w[u(205)](k),p[u(205)](w)})}return G}let ne=null,oe=null;function Ae(a,t){var p,f,y,h,E,u,w,M;const n=e,o=b[n(244)]("stackedChart1");if(!o)return;const i=[ae(a[n(202)](n(456))?(f=(p=t==null?void 0:t[n(436)])==null?void 0:p[n(258)])==null?void 0:f[n(470)]:(h=(y=t==null?void 0:t[n(173)])==null?void 0:y[n(258)])==null?void 0:h.total_interest),ae(a.includes(n(456))?(u=(E=t==null?void 0:t.result504_2_agg)==null?void 0:E[n(258)])==null?void 0:u[n(470)]:(M=(w=t==null?void 0:t[n(152)])==null?void 0:w.mortgage_expense)==null?void 0:M.total_interest)],l={labels:[n(294),"Loan 2"],datasets:[{type:n(391),label:n(143),backgroundColor:[n(465),n(465),n(465)],data:i,borderColor:n(314),borderWidth:2,hoverBorderColor:n(342),hoverBorderWidth:4,barPercentage:.6,categoryPercentage:.6,borderRadius:{topLeft:10,topRight:10,bottomLeft:10,bottomRight:10}}]},_={responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!0,labels:{color:n(418)}},tooltip:{enabled:!0,callbacks:{label:k=>"$ "+v(k[n(252)])}}},scales:{x:{grid:{display:!1}},y:{beginAtZero:!0,grid:{drawBorder:!1,borderDash:[6,2],color:n(165)},ticks:{callback:k=>"$ "+v(k)}}}};ne&&(ne.destroy(),ne=null);const s=o.getContext("2d");ne=new Chart(s,{type:n(391),data:l,options:_})}function Me(a,t){var p,f,y,h,E,u,w,M;const n=e,o=b[n(244)](n(347));if(!o)return;const i=[ae(a.includes("_agg")?(f=(p=t==null?void 0:t[n(436)])==null?void 0:p[n(315)])==null?void 0:f[n(313)]:(h=(y=t==null?void 0:t[n(173)])==null?void 0:y[n(315)])==null?void 0:h[n(313)]),ae(a[n(202)](n(456))?(u=(E=t==null?void 0:t[n(185)])==null?void 0:E[n(315)])==null?void 0:u.monthly_payment:(M=(w=t==null?void 0:t[n(152)])==null?void 0:w.calculated_data)==null?void 0:M.monthly_payment)],l={labels:["Loan 1",n(372)],datasets:[{type:n(391),label:n(345),backgroundColor:[n(410),"#F0EBCE","#F0EBCE"],data:i,borderColor:n(314),borderWidth:2,hoverBorderColor:"rgba(0, 0, 0, 0.2)",hoverBorderWidth:4,barPercentage:.6,categoryPercentage:.6,borderRadius:{topLeft:10,topRight:10,bottomLeft:10,bottomRight:10}}]},_={responsive:!0,maintainAspectRatio:!1,plugins:{legend:{display:!0,labels:{color:n(418)}},tooltip:{enabled:!0,callbacks:{label:k=>"$ "+v(k[n(252)])}}},scales:{x:{grid:{display:!1}},y:{beginAtZero:!0,grid:{drawBorder:!1,borderDash:[6,2],color:n(165)},ticks:{callback:k=>"$ "+v(k)}}}};oe&&(oe.destroy(),oe=null);const s=o.getContext("2d");oe=new Chart(s,{type:"bar",data:l,options:_})}async function we(){const a=e;I.textContent="Submitting...";const t=g[a(442)]((i,l)=>{const _=a;return i[l[_(380)]]=Number(l[_(183)]),i},{});t[a(318)]=t[a(243)],t[a(149)]=3,t[a(278)]=t.loan_amount_504_1+t[a(455)],t[a(179)]=t[a(287)]+t["504_bank_2_fees_a"]+t[a(414)]+t["504_bank_2_fees_c"]+t[a(406)],t[a(430)]=t[a(269)]+t[a(190)],delete t["7a_bank_loan_per"],delete t[a(482)],delete t[a(488)],delete t[a(155)],delete t[a(350)];const n=b[a(402)],o=(n==null?void 0:n[a(235)]("license-key"))||"";fetch(a(184)+o,{method:a(396),headers:{"Content-Type":a(242)},body:JSON[a(323)](t)}).then(i=>i[a(458)]())[a(198)](i=>{const l=a;I[l(441)]="Submitted",c=i,Le(),ye("doughnutChart",ve,{showCenterValue:!1,specialCharacter:"$ ",characterPlacement:l(147),centerColor:l(405),legendElementId:l(289),displayLegend:!1});const _=r("#result_container"),s=_[l(277)];s[l(180)][l(492)]=l(290);const p=r(l(262)),f=p[l(277)];f[l(180)][l(492)]=l(290);const y=r("#schedule_wrapper");y[l(180)][l(492)]=l(290),x(l(364)),setTimeout(()=>I[l(441)]=l(223),5e3)}).catch(i=>{const l=a;I[l(441)]="Submit",console[l(229)](l(253),i)})}const L=a=>{const t=e;I[t(441)]="Re-Submit";const n=g[t(371)](h=>h.id===a.id);if(n===-1)return;let o=a[t(183)]||0;if(o=O(o),o[t(416)](0)==="0"&&o[t(210)]>1&&!o.includes(".")&&(o=o[t(446)]("0","")),!J(o)){const h=o[t(321)](/[a-zA-Z]/);return h!==-1?b.getElementById(a.id).value=o[t(150)](0,h)+o[t(150)](h+1):b[t(244)](a.id).value=o[t(150)](0,-1),null}g[n][t(183)]=o,o===""&&g[n][t(281)]?g[n][t(153)]=!0:g[n][t(153)]=!1;const i=b[t(244)](a.id);i&&i.value[t(484)]()&&(i.style.border=""),ue(g,n);const l=r("#result_container"),_=l.parentElement;_[t(180)][t(492)]=t(230);const s=r("#view_area_wrapper"),p=s[t(277)];p[t(180)].display="none";const f=r(t(398));f[t(180)][t(492)]=t(230);const y={...ve,datasets:[{...ve.datasets[0],data:[m(t(448)).value,m("504_bank_loan_1_amount").value,m("504_bank_loan_2_amount").value]}]};ye(t(256),y,{showCenterValue:!1,specialCharacter:"$ ",characterPlacement:t(147),centerColor:t(405),legendElementId:"doughLegend",displayLegend:!1})};function Le(){var t,n,o,i,l,_,s,p,f,y,h,E,u,w,M,k;const a=e;C(c)||(r(a(331))[a(441)]=((n=(t=c==null?void 0:c[a(173)])==null?void 0:t[a(315)])==null?void 0:n[a(313)])||"-",r(a(187))[a(441)]=((i=(o=c==null?void 0:c.result504_1)==null?void 0:o[a(258)])==null?void 0:i.total_interest)||"-",r("#result504_1_fees")[a(441)]=v(String(m(a(455))[a(183)]||0)),r("#result504_2_monthly")[a(441)]=((_=(l=c==null?void 0:c.result504_2)==null?void 0:l.calculated_data)==null?void 0:_[a(313)])||"-",r("#result504_2_total_interest").textContent=((p=(s=c==null?void 0:c.result504_2)==null?void 0:s[a(258)])==null?void 0:p[a(470)])||"-",r(a(333)).textContent=v(String(m("504_bank_2_fees_a")[a(183)]||0)),r("#result504_2_fees_b")[a(441)]=v(String(m(a(414))[a(183)]||0)),r(a(390))[a(441)]=v(String(m("504_bank_2_fees_c")[a(183)]||0)),r("#result504_2_fees_d")[a(441)]=v(String(m(a(406))[a(183)]||0)),r("#result504_1_agg_monthly")[a(441)]=((y=(f=c==null?void 0:c[a(436)])==null?void 0:f[a(315)])==null?void 0:y[a(313)])||"-",r("#result504_1_agg_total_interest")[a(441)]=((E=(h=c==null?void 0:c[a(436)])==null?void 0:h[a(258)])==null?void 0:E.total_interest)||"-",r(a(474))[a(441)]=((w=(u=c==null?void 0:c[a(185)])==null?void 0:u[a(315)])==null?void 0:w[a(313)])||"-",r(a(388))[a(441)]=((k=(M=c==null?void 0:c[a(185)])==null?void 0:M[a(258)])==null?void 0:k[a(470)])||"-",re(),U(Q),Se())}function ze(a,t){const n=e,o=[];return a[n(379)](i=>{const l=n,_={};i.forEach((s,p)=>{const f=t[p];_[f]=s}),o[l(477)](_)}),o}function Se(){var o;const a=e,t=r(a(349));if(!t)return;t.innerHTML="",ze((o=c==null?void 0:c[a(152)])==null?void 0:o[a(440)],["Payment_Number",a(264),a(429),a(319)])[a(379)]((i,l)=>{const _=a,s=document.createElement("p");s[_(441)]="Year "+(l+1)+_(283)+v(String((i==null?void 0:i[_(319)])??0)),t.appendChild(s)})}function re(){const a=e,t=r(a(267));t&&(t[a(441)]=ce===a(424)?Q[a(446)](a(457),"")+" Table":a(386))}function T(a,t){const n=e,o=t[n(365)](l=>l.id===a);if(!o||!o[n(419)])return;const i=b[n(244)](o.id);i&&(i.innerHTML="",o[n(419)][n(379)](l=>{const _=n,s=document[_(160)]("option");s.value=l[_(183)],s[_(441)]=l[_(245)],l[_(183)]===o[_(183)]&&(s[_(248)]=!0),i[_(205)](s)}),i[n(385)]=!!o[n(385)],i[n(275)]=!!o.isRequired)}T(e(488),g),T(e(155),g),T("504_bank_loan_1_term",g),T(e(298),g),T(e(350),g),T(e(443),g),T(e(382),g),T(e(362),g),T(e(411),g),T(e(383),g),T(e(177),g),T(e(406),g);const ie={};function U(a){var ke;const t=e;Q=a,re();const n=r(t(218)),o=r(t(199)),i=r(t(308));if(!i||!n)return;n[t(485)]="<thead></thead><tbody></tbody>",o.innerHTML="";const l=((ke=c==null?void 0:c[a])==null?void 0:ke[t(358)])||[];if(C(l)){i[t(485)]="",i[t(441)]=t(431);return}const _=[t(451),t(264),t(429),t(319)];!ie[a]&&(ie[a]={currentPage:1,rowsPerPage:18});let{currentPage:s,rowsPerPage:p}=ie[a];n[t(180)].width=t(172),n[t(180)].borderCollapse=t(408);const f=document[t(160)](t(227)),y=document[t(160)]("tr");_.forEach(P=>{const q=t,z=document[q(160)]("th");z[q(441)]=P[q(140)]("_"," "),z.style.textAlign=q(154),z[q(180)].padding=q(162),y[q(205)](z)}),f.appendChild(y),n[t(205)](f);const h=document[t(160)]("tbody");n[t(205)](h),o[t(180)][t(492)]=t(238),o[t(180)][t(427)]=t(261),o[t(180)][t(209)]=t(154),o[t(180)][t(260)]=t(412),o[t(180)][t(215)]=t(389);const E=document[t(160)](t(328));E[t(166)]=t(374),E[t(180)][t(357)]=t(300),E.innerHTML=t(220);const u=document[t(160)](t(222));u.id="rowsPerPage_"+a,[10,18,25,50].forEach(P=>{const q=t,z=document[q(160)](q(450));z[q(183)]=P,z[q(441)]=P,P===p&&(z[q(248)]=!0),u[q(205)](z)}),E[t(205)](u);const w=document[t(160)](t(328));w[t(166)]=t(376),w[t(180)].display=t(238),w[t(180)][t(209)]=t(154),w[t(180)].gap=t(353);const M=document[t(160)]("span");M.id=t(404)+a,M[t(180)].fontSize=t(403);const k=document[t(160)](t(254));k[t(271)]=t(254),k.id="prev_"+a,k[t(441)]="◀",k[t(180)].border=t(230),k[t(180)][t(471)]=t(348),k[t(180)][t(204)]="transparent";const N=document[t(160)](t(254));N[t(271)]="button",N.id="next_"+a,N.textContent="▶",N.style.border="none",N[t(180)].cursor="pointer",N[t(180)].backgroundColor=t(314),w[t(205)](M),w[t(205)](k),w[t(205)](N),o[t(205)](E),o[t(205)](w);function le(){const P=t,q=(s-1)*p,z=q+p,Ie=l.slice(q,z);h[P(485)]="",Ie[P(379)](Re=>{const D=P,_e=document[D(160)]("tr");_e[D(180)][D(310)]=D(171),_e.style[D(260)]=D(266),_.forEach((ya,Be)=>{const F=D,ee=document[F(160)]("td");let Z=Re[Be];Z!=null&&!isNaN(Number(String(Z)[F(446)](/[^0-9.-]/g,"")))&&(Z=v(String(Z))),ee[F(441)]=Z??"",ee[F(180)][F(260)]=F(191),ee[F(180)][F(247)]=F(154),h.appendChild(ee),_e.appendChild(ee)}),h.appendChild(_e)});const fe=l[P(210)];M[P(441)]=q+1+"-"+Math[P(439)](z,fe)+P(469)+fe,k[P(385)]=s===1,N[P(385)]=z>=fe,ie[a]={currentPage:s,rowsPerPage:p}}u.addEventListener(t(481),P=>{const q=t;p=parseInt(P[q(472)][q(183)],10),s=1,le()}),k.addEventListener(t(381),()=>{s>1&&(s--,le())}),N[t(255)](t(381),()=>{const P=t,q=Math.ceil(l[P(210)]/p);s<q&&(s++,le())}),le()}function K(a){const t=e;[r(t(320)),r(t(316)),r(t(435)),r(t(421))].forEach(o=>{const i=t;if(!o)return;const l=o[i(145)][i(472)]===a;o.textContent=i(l?330:420)+i(274),o.style.setProperty("color",l?"#1a2980":i(478),"important"),o[i(180)].setProperty(i(215),l?"rgba(225,225,225,0.4)":i(361),"important"),o[i(306)].toggle(i(479),l)})}const Te=r(e(445)),X=r(e(296));X.style[e(492)]=e(230),Te.addEventListener("change",a=>{const t=e;a[t(472)].checked?(be=!0,X[t(180)][t(492)]=t(290),X.style[t(317)]=t(300),X.style[t(247)]=t(147)):(be=!1,X.style[t(492)]=t(230)),ue(g,-1)}),r(e(272))[e(255)](e(344),a=>L(a.target)),r(e(346))[e(255)](e(481),a=>L(a[e(472)])),r(e(366))[e(255)](e(481),a=>L(a[e(472)])),r(e(460)).addEventListener("change",a=>L(a[e(472)])),r(e(201))[e(255)](e(481),a=>L(a.target)),r("#504_bank_loan_1_amortization")[e(255)](e(481),a=>L(a[e(472)])),r(e(302))[e(255)](e(344),a=>L(a[e(472)])),r(e(303))[e(255)](e(481),a=>L(a.target)),r("#504_bank_loan_2_amortization")[e(255)](e(481),a=>L(a[e(472)])),r(e(428))[e(255)]("input",a=>L(a[e(472)])),r("#504_bank_1_fee_rate")[e(255)](e(481),a=>L(a[e(472)])),r(e(394))[e(255)](e(481),a=>L(a[e(472)])),r(e(144))[e(255)](e(481),a=>L(a[e(472)])),r(e(241))[e(255)]("change",a=>L(a[e(472)])),r("#504_bank_2_fees_d")[e(255)](e(481),a=>L(a[e(472)])),r("#main-form")[e(255)](e(151),a=>{const t=e;a[t(304)](),I.textContent=t(250),te(),we(),I[t(441)]=t(223),te()}),r(e(320))[e(255)]("click",()=>{const a=e;U(a(173)),K(a(173)),setTimeout(()=>x(a(186)))}),r(e(316)).addEventListener(e(381),()=>{const a=e;U(a(152)),K(a(152)),setTimeout(()=>x("view_title"))}),r(e(435))[e(255)](e(381),()=>{const a=e;U(a(436)),K(a(436)),setTimeout(()=>x("view_title"))}),r(e(421)).addEventListener(e(381),()=>{const a=e;U(a(185)),K(a(185)),setTimeout(()=>x(a(186)))});const V=r(e(387)),H=r(e(203));r("#nav_table").addEventListener("click",()=>{const a=e;V[a(180)][a(468)]=a(478),V.style.background=a(288),V[a(180)][a(329)]="rgba(17, 17, 26, 0.1) 0px 4px 16px",H[a(180)][a(468)]="black",H[a(180)][a(215)]="transparent",H[a(180)][a(329)]=a(169),ce="Table",re(),r(a(212))[a(180)][a(492)]=a(230),r(a(297))[a(180)][a(492)]=a(290)}),r(e(203))[e(255)](e(381),()=>{const a=e;H[a(180)][a(468)]="white",H[a(180)].background=a(288),H[a(180)][a(329)]=a(197),V[a(180)][a(468)]=a(288),V[a(180)][a(215)]=a(314),V[a(180)][a(329)]=a(169),ce=a(178),re(),r("#chartContainer").style[a(492)]="block",r(a(297))[a(180)][a(492)]=a(230),Ae(Q,c),Me(Q,c)}),ue(g,-1),we(),K("result504_1"),te();const Y=r(e(487));if(Y){const a=new IntersectionObserver(t=>{const n=e;t[n(379)](o=>{const i=n;o[i(337)]&&(Y[i(180)][i(286)]="1",Y[i(180)][i(393)]=i(195),Y[i(180)][i(239)]=i(341),a.unobserve(Y))})},{threshold:.3});a[e(473)](Y)}}function Fe(b,e={}){const r=document.createElement("template");r.innerHTML=`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>SBA 504 Loan Calculator</title>
</head>
<body>
  <div class="container">
    <div class="subContainer">

      <!-- Header / Hero -->
      <div class="firstSection">
        <div class="content">
            <h1>SBA 504 Loan Calculator</h1>

            <div class="accordion">
                <div class="top">
                    <div class="text">Software Details</div>
                    <span>+</span>
                    <input type="checkbox" />
                </div>
                <div class="bottom">
                    <div class="text">
                        SBA 504 Loan Calculator. 
                        <br/>
                        Enter the Purchase Price of your asset / building and the software does a complete analysis for a SBA 504 Loan -
                        <br/>
                        Updated April 29, 2025
                    </div>
                </div>
            </div>
        </div>
      </div>

      <!-- Main area -->
    <div class="secondSection" id="main-form-area">
        <div class="formContainer">
            <!-- ======= FORM (static DOM) ======= -->
            <form id="main-form" onsubmit="(function(e){ e.preventDefault(); return false; })(event)">
    
                <!-- Purchase price block -->
                <div class="block --group --purchase_price">
                    <div class="heading">
                        Purchase Price :
                        <div class="--field">
                            <input inputmode="numeric" id="purchase_price" name="purchase_price" type="text" placeholder="0" />
                        </div>
                    </div>
    
                    <div class="pricing_field">
                        <div>
                            <div>Are you a manufacturer or a Green Business</div>
                            
                            <div class="toggle-container">
                                <input type="checkbox" id="toggle-input" class="toggle-input">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 292 142" class="toggle">
                                    <path d="M71 142C31.7878 142 0 110.212 0 71C0 31.7878 31.7878 0 71 0C110.212 0 119 30 146 30C173 30 182 0 221 0C260 0 292 31.7878 292 71C292 110.212 260.212 142 221 142C181.788 142 173 112 146 112C119 112 110.212 142 71 142Z" class="toggle-background"></path>
                                    <rect rx="6" height="64" width="12" y="39" x="64" class="toggle-icon on"></rect>
                                    <path d="M221 91C232.046 91 241 82.0457 241 71C241 59.9543 232.046 51 221 51C209.954 51 201 59.9543 201 71C201 82.0457 209.954 91 221 91ZM221 103C238.673 103 253 88.6731 253 71C253 53.3269 238.673 39 221 39C203.327 39 189 53.3269 189 71C189 88.6731 203.327 103 221 103Z" fill-rule="evenodd" class="toggle-icon off"></path>
                                    <g filter="url('#goo')">
                                    <rect fill="#fff" rx="29" height="58" width="116" y="42" x="13" class="toggle-circle-center"></rect>
                                    <rect fill="#fff" rx="58" height="114" width="114" y="14" x="14" class="toggle-circle left"></rect>
                                    <rect fill="#fff" rx="58" height="114" width="114" y="14" x="164" class="toggle-circle right"></rect>
                                    </g>
                                    <filter id="goo">
                                    <feGaussianBlur stdDeviation="10" result="blur" in="SourceGraphic"></feGaussianBlur>
                                    <feColorMatrix result="goo" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7" mode="matrix" in="blur"></feColorMatrix>
                                    </filter>
                                </svg>
                            </div>
                        </div>
    
                        <div id="manufacturer-content" class="hide-content">
                            The maximum amount on the CDC Loan (2) increases from $5 Million to $5.5 Million
                        </div>
                    </div>
                </div>
    
                <!-- Main form groups (504 + fees etc.) -->
                <div class="block">
                    <div class="--second_form_container">
                        <div id="group_504">
                            <h3>504</h3>
    
                            <!-- Pie chart area (desktop) -->
                            <div id="_pie_chart" class="_pie_chart">
                                <div class="_sticky_container">
                                    <div class="doughnut-wrapper">
                                        <div class="doughnut-card">
                                            <div class="doughnut-canvas-wrap">
                                                <canvas  class="doughnutChart" id="doughnutChart" aria-label="Doughnut chart"></canvas>
                                            </div>
                                            <div id="doughLegend" class="dough-legend"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- DOWN PAYMENT -->
                            <div class="--group">
                                <div class="heading" style="display:flex; align-items:center;">
                                    DOWN PAYMENT
                                    <span id="alert_504_down_payment_per" style="margin-left:8px;"></span>
                                </div>
        
                                <div class="--interest_rates">
                                    <div class="--field" id="field_504_down">
                                        <div>
                                            <label class="--label" for="504_down_payment_per">Per.</label>
                                            <select id="504_down_payment_per" name="504_down_payment_per">
                                                <!-- dynamically add options -->
                                            </select>
                                        </div>
        
                                        <div>
                                            <label class="--label" for="504_down_payment_amount">Amount</label>
                                            <input inputmode="numeric" disabled id="504_down_payment_amount" name="504_down_payment_amount" type="text" placeholder="$ 0" />
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                            <!-- Bank Loan 1 -->
                            <div class="--group" style="border:none; position:relative;">
                                <div>
                                    <div class="heading" style="display:flex; align-items:center;">
                                        BANK LOAN 1
                                        <span id="alert_504_bank_loan_1_per" style="margin-left:8px;"></span>
                                    </div>
        
                                    <div class="--interest_rates">
                                        <div class="--field" id="field_504_bl1">
                                            <div>
                                                <label class="--label" for="504_bank_loan_1_per">Per.</label>
                                                <select id="504_bank_loan_1_per" name="504_bank_loan_1_per">
                                                    <!-- dynamically add options -->
                                                </select>
                                            </div>
            
                                            <div>
                                                <label class="--label" for="504_bank_loan_1_amount">Amount</label>
                                                <input inputmode="numeric" disabled id="504_bank_loan_1_amount" name="504_bank_loan_1_amount" type="text" placeholder="$ 0" />
                                            </div>
                                        </div>
                                    </div>
        
                                    <div style="padding-top:20px;">
                                        <div class="--interest_rates">
                                            <div class="--field" style="width:100%; text-align:initial;">
                                                <label class="--label" for="504_bank_loan_1_term">Term</label>
                                                <select id="504_bank_loan_1_term" name="504_bank_loan_1_term" style="width:66%; max-width:330px;">
                                                    <!-- dynamically add options -->
                                                </select>
                                            </div>
                                        </div>
            
                                        <div class="--interest_rates">
                                            <div class="--field" style="width:100%; text-align:initial;">
                                                <label class="--label" for="504_bank_loan_1_amortization">Amortization</label>
                                                <select id="504_bank_loan_1_amortization" name="504_bank_loan_1_amortization" style="width:66%; max-width:330px;">
                                                    <!-- dynamically add options -->
                                                </select>
                                            </div>
                                        </div>
            
                                        <div class="--interest_rates">
                                            <div class="--field">
                                                <label class="--label" for="504_bank_loan_1_rate">Rate</label>
                                                <input inputmode="numeric" id="504_bank_loan_1_rate" name="504_bank_loan_1_rate" type="text" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                            <!-- CDC Loan 2 -->
                            <div class="--group" style="border:none; position:relative;">
                                <hr/>
                                <div class="heading" style="display:flex; align-items:center;">
                                    CDC LOAN 2
                                    <span id="alert_504_bank_loan_2_per" style="margin-left:8px;"></span>
                                </div>
        
                                <div class="--interest_rates">
                                    <div class="--field" id="field_504_bl2">
                                        <div>
                                            <label class="--label" for="504_bank_loan_2_per">Per.</label>
                                            <select id="504_bank_loan_2_per" name="504_bank_loan_2_per">
                                                <!-- dynamically add options -->
                                            </select>
                                        </div>
                                        <div>
                                            <label class="--label" for="504_bank_loan_2_amount">Amount</label>
                                            <input inputmode="numeric" disabled id="504_bank_loan_2_amount" name="504_bank_loan_2_amount" type="text" placeholder="$ 0" />
                                        </div>
                                    </div>
                                </div>
        
                                <div style="padding-top:20px;">
                                    <div class="--interest_rates">
                                        <div class="--field" style="width:100%; text-align:initial;">
                                            <label class="--label" for="504_bank_loan_2_term">Term</label>
                                            <select id="504_bank_loan_2_term" name="504_bank_loan_2_term" style="width:66%; max-width:330px;">
                                                <!-- dynamically add options -->
                                            </select>
                                        </div>
                                    </div>
        
                                    <div class="--interest_rates">
                                        <div class="--field" style="width:100%; text-align:initial;">
                                            <label class="--label" for="504_bank_loan_2_amortization">Amortization</label>
                                            <select id="504_bank_loan_2_amortization" name="504_bank_loan_2_amortization" style="width:66%; max-width:330px;">
                                                <!-- dynamically add options -->
                                            </select>
                                        </div>
                                    </div>
        
                                    <div class="--interest_rates">
                                        <div class="--field">
                                            <label class="--label" for="504_bank_loan_2_rate">Rate</label>
                                            <input inputmode="numeric" id="504_bank_loan_2_rate" name="504_bank_loan_2_rate" type="text" />
                                        </div>
                                    </div>
                                </div>
    
                            </div>
    
                            <!-- Fees sections (Bank Loan 1 Fees) -->
                            <div class="--group">
                            <hr/>
                            <div class="heading" style="display:flex">Bank Loan 1 - Fees</div>
                            <div class="--interest_rates">
                                <div class="--field">
                                <div>
                                    <label class="--label" for="504_bank_1_fee_rate">Per.</label>
                                    <select id="504_bank_1_fee_rate" name="504_bank_1_fee_rate">
                                        <!-- dynamically add options -->
                                    </select>
                                </div>
                                <div>
                                    <label class="--label" for="504_bank_1_fees">Amount</label>
                                    <input inputmode="numeric" disabled id="504_bank_1_fees" name="504_bank_1_fees" type="text" />
                                </div>
                                </div>
                            </div>
                            </div>
    
                            <!-- Bank Loan 2 (CDC) - fees rows -->
                            <div class="--group" style="border:none">
                            <div class="heading" style="display:flex">Bank Loan 2(CDC) - Fees</div>
    
                            <div style="text-align:start; margin-left:5px; margin-bottom:15px;">SBA Guaranty Fee</div>
                            <div class="--field">
                                <div>
                                    <label class="--label" for="504_bank_2_fee_rate_a">Per.</label>
                                    <select id="504_bank_2_fee_rate_a" name="504_bank_2_fee_rate_a">
                                        <!-- dynamically add options -->
                                    </select>
                                </div>
                                <div>
                                    <label class="--label" for="504_bank_2_fees_a">Amount</label>
                                    <input inputmode="numeric" disabled id="504_bank_2_fees_a" name="504_bank_2_fees_a" type="text" />
                                </div>
                            </div>
    
                            <div style="text-align:start; margin-left:5px; margin-bottom:15px;">CDC Processing Fee</div>
                            <div class="--interest_rates">
                                <div class="--field">
                                <div>
                                    <label class="--label" for="504_bank_2_fee_rate_b">Per.</label>
                                    <select id="504_bank_2_fee_rate_b" name="504_bank_2_fee_rate_b">
                                        <!-- dynamically add options -->
                                    </select>
                                </div>
                                <div>
                                    <label class="--label" for="504_bank_2_fees_b">Amount</label>
                                    <input inputmode="numeric" disabled id="504_bank_2_fees_b" name="504_bank_2_fees_b" type="text" />
                                </div>
                                </div>
                            </div>
    
                            <div style="text-align:start; margin-left:5px; margin-bottom:15px;">Document Fee</div>
                            <div class="--interest_rates">
                                <div class="--field">
                                <div>
                                    <label class="--label" for="504_bank_2_fee_rate_c">Per.</label>
                                    <select id="504_bank_2_fee_rate_c" name="504_bank_2_fee_rate_c">
                                        <!-- dynamically add options -->
                                    </select>
                                </div>
                                <div>
                                    <label class="--label" for="504_bank_2_fees_c">Amount</label>
                                    <input inputmode="numeric" disabled id="504_bank_2_fees_c" name="504_bank_2_fees_c" type="text" />
                                </div>
                                </div>
                            </div>
    
                            <div style="text-align:start; margin-left:5px; margin-bottom:15px;">Attorney Fees</div>
                            <div class="--field">
                                <div>
                                    <label class="--label" for="504_bank_2_fees_d">Per.</label>
                                    <select id="504_bank_2_fees_d" name="504_bank_2_fees_d">
                                        <!-- dynamically add options -->
                                    </select>
                                </div>
                                <div>
                                    <label class="--label" for="504_bank_2_fees_d_input">Amount</label>
                                    <input inputmode="numeric" disabled id="504_bank_2_fees_d_input" name="504_bank_2_fees_d_input" type="text" disabled />
                                </div>
                            </div>
    
                            </div>
                        </div>    
                    </div>
                    <!-- Submit button -->
                    <button class="submit_button" id="submit_button" type="submit">Submit</button>
                </div>
            </form>
    
            <div class="block">
                <!-- ======= Results / Analytics (static placeholders to be filled by JS) ======= -->
                <div id="result_container" class="resultContainer">
                    <!-- PAYMENT DETAILS [Fees paid upfront] -->
                    <div id="payment_details_upfront">
                        <h3>PAYMENT DETAILS [Fees paid upfront]</h3>
                        <br />
                        <div style="width:100%; display:flex; gap:12px; flex-wrap:wrap;">
                        <!-- 504 Bank Loan 1 card -->
                        <div class="--card" id="card_result504_1">
                            <h4>504 Bank Loan 1</h4>
                            <div>
                            <p>Monthly Payment:</p>
                            <p id="result504_1_monthly">-</p>
                            <hr />
                            <p>Total Interest Paid:</p>
                            <p id="result504_1_total_interest">-</p>
                            </div>
                            <hr />
                            <div>
                            <p>Fees:</p>
                            <p>$ <span id="result504_1_fees">0</span></p>
                            </div>
                            <button class="table_view_btn_1" id="table_view_btn_1" type="button" data-target="result504_1">View Table</button>
                        </div>
    
                        <!-- 504 CDC Loan 2 card -->
                        <div class="--card" id="card_result504_2">
                            <h4>504 CDC Loan 2</h4>
                            <div>
                            <p>Monthly Payment:</p>
                            <p id="result504_2_monthly">-</p>
                            <hr />
                            <p>Total Interest Paid:</p>
                            <p id="result504_2_total_interest">-</p>
                            </div>
                            <hr />
                            <div>
                            <p>SBA Guarantee Fee:</p>
                            <p>$ <span id="result504_2_fees_a">0</span></p>
                            <hr />
                            <p>CDC Processing Fee:</p>
                            <p>$ <span id="result504_2_fees_b">0</span></p>
                            <hr />
                            <p>Document Fees:</p>
                            <p>$ <span id="result504_2_fees_c">0</span></p>
                            <hr />
                            <p>Attorney Fees:</p>
                            <p>$ <span id="result504_2_fees_d">0</span></p>
                            </div>
                            <button class="table_view_btn_2" id="table_view_btn_2" type="button" data-target="result504_2">View Table</button>
                        </div>
                        </div>
                    </div>
                    
                    <br />
                    <hr style="width:100%;" />
                    <br />
        
                    <!-- PAYMENT DETAILS - Fees amortized into the loan (aggregated results) -->
                    <div id="payment_details_aggregated">
                        <h3>PAYMENT DETAILS - [Fees amortized into the loan]</h3>
                        <br />
                        <div style="width:100%; display:flex; gap:12px; flex-wrap:wrap;">
                            <!-- Aggregated 504 Bank Loan 1 -->
                            <div class="--card" id="card_result504_1_agg">
                            <h4>504 Bank Loan 1</h4>
                            <div>
                                <p>Monthly Payment:</p>
                                <p id="result504_1_agg_monthly">-</p>
                                <hr />
                                <p>Total Interest Paid:</p>
                                <p id="result504_1_agg_total_interest">-</p>
                            </div>
                            <hr />
                            <div>
                                <p>Fees built into the loan</p>
                                <p id="result504_1_agg_fees">-</p>
                            </div>
                            <button class="table_view_btn_1_agg" id="table_view_btn_1_agg" type="button" data-target="result504_1_agg">View Table</button>
                            </div>
                
                            <!-- Aggregated 504 Bank Loan 2 -->
                            <div class="--card" id="card_result504_2_agg">
                            <h4>504 Bank Loan 2</h4>
                            <div>
                                <p>Monthly Payment:</p>
                                <p id="result504_2_agg_monthly">-</p>
                                <hr />
                                <p>Total Interest Paid:</p>
                                <p id="result504_2_agg_total_interest">-</p>
                            </div>
                            <hr />
                            <div>
                                <p>Fees built into the loan</p>
                                <p id="result504_2_agg_fees">-</p>
                            </div>
                            <button class="table_view_btn_2_agg" id="table_view_btn_2_agg" type="button" data-target="result504_2_agg">View Table</button>
                            </div>
                        </div>
                    </div>
                </div> <!-- end result_container -->
                
            </div>
        </div>


        <!-- Table / Graph navigation & container -->
        <div class="tableContainer">
            <div id="view_area_wrapper">
                <h2 id="view_title" style="color:#1a2980;">Table</h2>
                <div class="--navigation" id="--navigation">
                    <span id="nav_table" style="background: black; color: white; box-shadow: rgba(17, 17, 26, 0.1) 0px 4px 16px;">Table</span>
                    <span id="nav_graph">Graph</span>
                </div>

                <!-- Chart Section -->
                <!-- <div class="chartContainer">
                    <div class="chartCard">
                        <canvas id="stackedChart" width="350px" height="350px"></canvas>
                    </div>
                </div> -->
                <div id="chartContainer" class="chartContainer">
                    <div class="--chart_group">
                        <div class="--chart">
                            <canvas id="stackedChart1" width="350px" height="350px"></canvas>
                        </div>
                        <div class="--chart">
                            <canvas id="stackedChart2" width="350px" height="350px"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Table area -->
                <div id="tableContainer" style="display:block;">
                    <!-- Table will be injected here by JS -->
                    <div class="tableWrapper" id="tableContent">
                        <div class="amort-table-container" id="amort-table-container">
                            <table class="amort-table" id="amort-table">
                                <thead></thead>
                                <tbody></tbody>
                            </table>
                            <div class="amort-table-footer" id="amort-table-footer"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Schedule (prepayment penalty structure) -->
        <div id="schedule_wrapper" class="scheduleContainer">
            <div>
                <h3>Schedule 2 - Prepayment Penalty Structure</h3>
                <div>
                SBA 504 Prepayment Penalty Calculation <b>The prepayment Penalty assessed will be as follows</b>
                </div>
                <div class="--year_container" style="display:flex; justify-content:space-around; flex-wrap:wrap; margin:50px 0; padding:20px; border:1px solid rgba(0,0,0,0.1); border-radius:20px; background:white;">
                <div id="year_list">
                    <!-- JS will populate year rows like: <p>Year 1: $...</p> -->
                </div>
                </div>
            </div>
        </div>
    </div> <!-- secondSection -->
    </div>
  </div>
</body>
</html>
`,r.content.querySelectorAll("*").forEach(function(C){const v=C.getAttribute&&C.getAttribute("class");if(v&&v.length){const R=v.trim().split(/\s+/),W=[];for(let J=0;J<R.length;J++){const O=R[J];e&&Object.prototype.hasOwnProperty.call(e,O)?W.push(e[O]):W.push(O)}C.setAttribute("class",W.join(" "))}}),b.appendChild(r.content.cloneNode(!0))}const je=`:root{--primary-dark: #0e85ed;--primary-light: #62c4f5;--accent: #1a2980;--muted: rgba(0, 0, 0, .5);--card-shadow: rgba(99, 99, 99, .2) 0px 2px 8px 0px;--max-width: 1000px;--font-stack: "Helvetica Neue", Arial, sans-serif}*{box-sizing:border-box}:host{height:100%;margin:0;font-family:var(--font-stack);color:#111}._container_q72vo_23{container-type:inline-size}._firstSection_q72vo_28{background:linear-gradient(var(--primary-dark),var(--primary-light));min-height:20vh;margin-bottom:80px}._content_q72vo_33{display:flex;flex-direction:column;align-items:center;justify-content:center}._content_q72vo_33 h1{padding-top:60px;text-align:center;font-size:40px}._accordion_q72vo_47{max-width:550px;box-shadow:0 0 27px #00000040;background-color:transparent;border-radius:1rem;justify-content:flex-start;align-items:stretch;display:grid;grid-template-columns:1fr;grid-template-rows:.1fr 0fr;overflow:hidden;transition:grid-template-rows .3s cubic-bezier(.19,1,.22,1)}._accordion_q72vo_47 ._top_q72vo_61{cursor:pointer;align-items:center;justify-content:space-between;padding:1.85rem 1.5rem 1.75rem;display:flex;position:relative}._accordion_q72vo_47 ._top_q72vo_61 ._text_q72vo_70{font-size:1.25rem;font-weight:700;white-space:wrap}._accordion_q72vo_47 ._top_q72vo_61 span{align-self:flex-start;font-size:30px}._accordion_q72vo_47 ._top_q72vo_61 input{position:absolute;top:0;right:0;bottom:0;left:0;cursor:pointer;-webkit-appearance:none;-moz-appearance:none;appearance:none;border:none}._accordion_q72vo_47 ._bottom_q72vo_89{padding-inline:1.5rem;overflow:hidden;transition:all .3s cubic-bezier(.19,1,.22,1)}._accordion_q72vo_47 ._bottom_q72vo_89 ._text_q72vo_70{line-height:2;margin:0;padding-bottom:1.5rem}._accordion_q72vo_47:has(input:checked){grid-template-rows:.1fr 1fr}._accordion_q72vo_47:has(input:checked) ._top_q72vo_61 span{transform:rotate(45deg)}._secondSection_q72vo_111{background:#f0f8ff;background-size:400% 400%;position:relative}._block_q72vo_117{box-shadow:var(--card-shadow);background:#fff;margin:20px auto;padding:20px;border-radius:10px;width:86%}@container (max-width: 520px){._block_q72vo_117{padding:20px 10px}}._block_q72vo_117 h3{font-size:1.5rem}._formContainer_q72vo_135{text-align:center;max-width:var(--max-width);margin:0 auto;padding:60px 50px}@container (max-width: 580px){._formContainer_q72vo_135{padding:60px 10px}}._--second_form_container_q72vo_148{display:flex;justify-content:center;gap:16px;position:relative}@container (max-width: 480px){._--second_form_container_q72vo_148{display:block}}.__description_modal_q72vo_162{box-shadow:20px 20px 60px #d9d9d9,-20px -20px 60px #fff;min-width:200px;min-height:150px;border-radius:25px 0 25px 25px;position:absolute;left:0;padding:15px}._visible-animate_q72vo_174{opacity:1!important;transform:translate(0) scale(1)!important;transition:transform .8s ease,opacity .8s ease}.__pie_chart_q72vo_180{opacity:0;transform:translate(100px) scale(.95);transition:transform .8s ease,opacity .8s ease}.__pie_chart_q72vo_180{right:-100px;top:0;bottom:0;position:absolute;max-width:350px;width:100%;background:transparent}.__pie_chart_q72vo_180 .__sticky_container_q72vo_196{width:100%;min-height:150px;padding:10px;position:sticky;top:0}@container (max-width: 1080px){.__pie_chart_q72vo_180{position:relative;max-width:100%;height:auto;right:0;margin-bottom:40px}.__pie_chart_q72vo_180 .__sticky_container_q72vo_196{position:relative;height:auto}}@container (max-width: 480px){.__pie_chart_q72vo_180 .__sticky_container_q72vo_196{padding:0}}._--group_q72vo_228{margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid rgba(0,0,0,.1)}._--group_q72vo_228 ._heading_q72vo_233{font-size:1.4rem;justify-content:center;padding-bottom:25px;display:flex;gap:8px;align-items:center;max-width:600px}._--field_q72vo_243{display:flex;margin:10px 0;gap:12px;align-items:center;position:relative}._input-wrapper_q72vo_251 input{padding-left:35px;box-sizing:border-box}._dollar-prefix_q72vo_256{position:absolute;top:50%;left:15px;transform:translateY(-50%);color:#333;pointer-events:none;font-size:2rem}@container (max-width: 420px){._--field_q72vo_243{width:"100%";flex-direction:column;align-items:stretch}}._--field_q72vo_243>div{position:relative}._--label_q72vo_279{position:absolute;top:-14px;left:20px;line-height:1;background:#fff;padding:5px 10px;border-radius:10px;font-size:12px}@container (max-width: 420px){._--label_q72vo_279{top:-4px}}input,select,textarea{padding:10px 20px;margin:0 5px;border-radius:10px;border:1px solid rgba(0,0,0,.3);font-size:14px;outline:none}input:disabled{cursor:no-drop}@container (max-width: 420px){input,select{margin:10px 0;width:100%!important;max-width:550px!important}}select{cursor:pointer;padding:10px 40px 10px 20px;background:url("data:image/svg+xml,<svg height='10px' width='10px' viewBox='0 0 16 16' fill='%23000000' xmlns='http://www.w3.org/2000/svg'><path d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/></svg>") no-repeat;background-position:calc(100% - .75rem) center!important;appearance:none;-moz-appearance:none;-webkit-appearance:none}._--error_q72vo_333>div:nth-child(1) input,._--error_q72vo_333>div:nth-child(1) select{border:1px solid red!important}._--interest_rates_q72vo_339{display:flex;gap:12px;align-items:flex-start}@container (max-width: 920px){._--interest_rates_q72vo_339{flex-direction:column}}._pricing_field_q72vo_351{border-radius:10px;box-shadow:#0000000f 0 2px 4px inset;border:1px solid lightgrey;padding:20px 35px;width:100%;max-width:600px;margin:0 auto}._pricing_field_q72vo_351>div{display:flex;justify-content:space-between}._pricing_field_q72vo_351>div:first-child{align-items:center;gap:10px}._pricing_field_q72vo_351 p{padding:10px;background:#add8e6;border-radius:25px}._--purchase_price_q72vo_377{margin:0 auto;display:flex;flex-direction:column;align-items:center;justify-content:center}._--purchase_price_q72vo_377>div{text-align:center!important;z-index:2}._--purchase_price_q72vo_377>div:first-child{display:flex;align-items:end;justify-content:space-around;width:100%}._--purchase_price_q72vo_377 input{border:none;font-size:2rem;border-bottom:1px solid rgba(0,0,0,.3)}._--purchase_price_q72vo_377 ._toggle-container_q72vo_400{--active-color: #60b412;--inactive-color: #d3d3d6;position:relative;aspect-ratio:292 / 142;height:1.875em}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408{-webkit-appearance:none;-moz-appearance:none;appearance:none;margin:0;position:absolute;z-index:1;top:0;left:0;width:100%;height:100%;cursor:pointer;border:none}._--purchase_price_q72vo_377 ._toggle_q72vo_400{width:100%;height:100%;overflow:visible}._--purchase_price_q72vo_377 ._toggle-background_q72vo_427{fill:var(--inactive-color);transition:fill .4s}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408:checked+._toggle_q72vo_400 ._toggle-background_q72vo_427{fill:var(--active-color)}._--purchase_price_q72vo_377 ._toggle-circle-center_q72vo_436{transform-origin:center;transition:transform .6s}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408:checked+._toggle_q72vo_400 ._toggle-circle-center_q72vo_436{transform:translate(150px)}._--purchase_price_q72vo_377 ._toggle-circle_q72vo_436{transform-origin:center;transition:transform .45s;backface-visibility:hidden}._--purchase_price_q72vo_377 ._toggle-circle_q72vo_436._left_q72vo_451{transform:scale(1)}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408:checked+._toggle_q72vo_400 ._toggle-circle_q72vo_436._left_q72vo_451{transform:scale(0)}._--purchase_price_q72vo_377 ._toggle-circle_q72vo_436._right_q72vo_459{transform:scale(0)}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408:checked+._toggle_q72vo_400 ._toggle-circle_q72vo_436._right_q72vo_459{transform:scale(1)}._--purchase_price_q72vo_377 ._toggle-icon_q72vo_467{transition:fill .4s}._--purchase_price_q72vo_377 ._toggle-icon_q72vo_467._on_q72vo_471{fill:var(--inactive-color)}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408:checked+._toggle_q72vo_400 ._toggle-icon_q72vo_467._on_q72vo_471{fill:#fff}._--purchase_price_q72vo_377 ._toggle-icon_q72vo_467._off_q72vo_479{fill:#eaeaec}._--purchase_price_q72vo_377 ._toggle-input_q72vo_408:checked+._toggle_q72vo_400 ._toggle-icon_q72vo_467._off_q72vo_479{fill:var(--active-color)}@container (max-width: 920px){._--purchase_price_q72vo_377 input{font-size:1.5rem}}@container (max-width: 680px){._--purchase_price_q72vo_377 input{font-size:1.2rem}}@container (max-width: 560px){._--purchase_price_q72vo_377 input{font-size:1rem;border:1px solid rgba(0,0,0,.3)}}._submit_button_q72vo_505{width:fit-content;border:none;background:#000;color:#fff;padding:10px 100px;border-radius:20px;margin:50px 0;cursor:pointer}._submit_button_q72vo_505:hover{box-shadow:#000000bf 0 3px 8px}._submit_button_q72vo_505._--disabled_q72vo_518,._submit_button_q72vo_505:disabled{cursor:no-drop!important;background:#bfcfe8;box-shadow:none!important}._resultContainer_q72vo_526{display:none;padding:20px 50px;display:flex;align-items:center;flex-direction:column}@container (max-width: 768px){._resultContainer_q72vo_526{padding:20px}}@container (max-width: 480px){._resultContainer_q72vo_526{padding:0}}._--card_q72vo_544{box-shadow:#32325d40 0 13px 27px -5px,#0000004d 0 8px 16px -8px;display:flex;justify-content:space-between;width:100%;margin:0 10px 40px;border-radius:20px;padding:20px;text-align:center}@container (max-width: 768px){._--card_q72vo_544{flex-direction:column}}@container (max-width: 480px){._--card_q72vo_544{margin:0 0 40px;padding:20px 0}}._--card_q72vo_544 h4{font-size:1rem;font-weight:900;transform:rotate(180deg);-webkit-writing-mode:vertical-lr}@container (max-width: 768px){._--card_q72vo_544 h4{transform:rotate(0);-webkit-writing-mode:horizontal-tb}}._--card_q72vo_544 p{margin:0;padding-bottom:5px}._--card_q72vo_544>div{width:40%;margin:0 10px;border:1px solid rgba(0,0,0,.1);padding:20px 10px;border-radius:20px}@container (max-width: 768px){._--card_q72vo_544>div{width:auto}}._table_view_btn_q72vo_596,._table_view_btn_1_q72vo_597,._table_view_btn_2_q72vo_598,._table_view_btn_1_agg_q72vo_599,._table_view_btn_2_agg_q72vo_600{border:none;background:#1a2980;color:#fff;padding:10px 20px;border-radius:20px;cursor:pointer;transform:rotate(180deg);will-change:transform,writing-mode;-o-transform:rotate(180deg);-ms-transform:rotate(180deg);-moz-transform:rotate(180deg);-webkit-transform:rotate(180deg);writing-mode:vertical-lr;-webkit-writing-mode:vertical-lr}@container (max-width: 768px){._table_view_btn_q72vo_596,._table_view_btn_1_q72vo_597,._table_view_btn_2_q72vo_598,._table_view_btn_1_agg_q72vo_599,._table_view_btn_2_agg_q72vo_600{transform:rotate(0);will-change:transform,writing-mode;-o-transform:rotate(0deg);-ms-transform:rotate(0deg);-moz-transform:rotate(0deg);-webkit-transform:rotate(0deg);writing-mode:horizontal-tb;-webkit-writing-mode:horizontal-tb;width:100%;max-width:220px;margin:20px auto 0}}._table_view_btn_q72vo_596:hover{box-shadow:#000000bf 0 3px 8px}._--activeBtn_q72vo_640{background:#e1e1e166!important;color:var(--accent)!important}._chartContainer_q72vo_646{display:none;max-width:1000px;margin:0 auto;padding:80px 0}._chartContainer_q72vo_646>div{box-shadow:#110c2e26 0 48px 100px;border-radius:20px;padding:50px}@container (max-width: 520px){._chartContainer_q72vo_646>div{margin:30px 10px;padding:20px}}._chartContainer_q72vo_646 ._--chart_group_q72vo_666{display:flex;justify-content:space-between}@container (max-width: 1000px){._chartContainer_q72vo_646 ._--chart_group_q72vo_666{flex-direction:column}}._chartContainer_q72vo_646 ._--chart_q72vo_666 canvas{width:350px}._doughnut-wrapper_q72vo_681{max-width:500px;padding:18px;background:#fff;border-radius:0 25px 25px;box-shadow:20px 20px 60px #d9d9d9,-20px -20px 60px #fff}._doughnut-card_q72vo_690{border-radius:14px;display:flex;flex-direction:column;align-items:center}._doughnut-canvas-wrap_q72vo_697{width:250px;height:250px;position:relative}._doughnutChart_q72vo_703{width:100%!important;height:100%!important;display:block}._dough-legend_q72vo_709{margin-top:12px;display:flex;gap:18px;flex-wrap:wrap;justify-content:center}._legend-item_q72vo_718{display:inline-flex;align-items:center;gap:8px;font-size:13px;color:#95a3a8}._legend-swatch_q72vo_725{width:12px;height:12px;border-radius:3px;display:inline-block}._legend-label_q72vo_731{font-size:13px;color:#95a3a8}._--navigation_q72vo_737{max-width:800px;margin:0 auto;padding:20px 30px;border-radius:30px;display:flex;justify-content:space-around;box-shadow:#ccdbe8 3px 3px 6px inset,#ffffff80 -3px -3px 6px 1px inset}._--navigation_q72vo_737 span{border-radius:10px;padding:10px 30px;cursor:pointer;box-shadow:#32326926 0 2px 5px}._--navigation_q72vo_737 span:hover{background:#000;color:#fff;box-shadow:#11111a1a 0 4px 16px}._scheduleContainer_q72vo_760{display:none;padding:60px 50px 100px;background:0% 0% / 400% 400% #f0f8ff}@container (max-width: 580px){._scheduleContainer_q72vo_760{padding:60px 20px 100px}}._scheduleContainer_q72vo_760>div{margin:auto;max-width:900px}._scheduleContainer_q72vo_760 h3{font-size:1.5em}._--year_container_q72vo_781{display:flex;justify-content:space-around;flex-wrap:wrap;margin:50px 0;padding:20px;border:1px solid rgba(0,0,0,.1);border-radius:20px;background:#fff}@container (max-width: 580px){._--year_container_q72vo_781{flex-direction:column;text-align:center}._--year_container_q72vo_781>div:first-child{margin-bottom:20px;padding-bottom:10px;border-bottom:1px solid rgba(0,0,0,.1)}}._tableContainer_q72vo_804{display:none;text-align:center;padding:60px 50px 100px;background:#e1e1e166}._tableContainer_q72vo_804>div{margin:auto;max-width:900px}@container (max-width: 768px){._tableContainer_q72vo_804{padding:60px 10px}}@container (max-width: 480px){._tableWrapper_q72vo_822{overflow-x:scroll;-webkit-overflow-scrolling:touch}._tableWrapper_q72vo_822::-webkit-scrollbar{display:none}}._amort-table-container_q72vo_831{max-width:1000px;margin:80px auto 20px;border-radius:15px;overflow:hidden;box-shadow:#32325d40 0 13px 27px -5px,#0000004d 0 8px 16px -8px;background:#fff}@container (max-width: 480px){._amort-table-container_q72vo_831{width:max-content}}._amort-table_q72vo_831 thead tr{background:#000;color:#fff}._amort-table_q72vo_831 thead th{font-weight:600;text-align:center}._amort-table_q72vo_831 tbody tr:hover{background:#f9f9f9}._amort-table_q72vo_831 td,._amort-table_q72vo_831 th{border-bottom:1px solid #eee;padding:10px 12px}._amort-table_q72vo_831 td:first-child{font-weight:500}._amort-table-footer_q72vo_871 button:disabled{cursor:no-drop!important}`,De="_container_q72vo_23",$e="_firstSection_q72vo_28",We="_content_q72vo_33",Oe="_accordion_q72vo_47",Ge="_top_q72vo_61",Ve="_text_q72vo_70",He="_bottom_q72vo_89",Ye="_secondSection_q72vo_111",Ze="_block_q72vo_117",Je="_formContainer_q72vo_135",Qe="__description_modal_q72vo_162",Ue="__pie_chart_q72vo_180",Ke="__sticky_container_q72vo_196",Xe="_heading_q72vo_233",ea="_pricing_field_q72vo_351",aa="_toggle_q72vo_400",ta="_left_q72vo_451",na="_right_q72vo_459",oa="_on_q72vo_471",ra="_off_q72vo_479",ia="_submit_button_q72vo_505",la="_resultContainer_q72vo_526",_a="_table_view_btn_q72vo_596",xa="_table_view_btn_1_q72vo_597",da="_table_view_btn_2_q72vo_598",sa="_table_view_btn_1_agg_q72vo_599",ca="_table_view_btn_2_agg_q72vo_600",ba="_chartContainer_q72vo_646",pa="_doughnutChart_q72vo_703",ua="_scheduleContainer_q72vo_760",va="_tableContainer_q72vo_804",fa="_tableWrapper_q72vo_822",ga={container:De,firstSection:$e,content:We,accordion:Oe,top:Ge,text:Ve,bottom:He,secondSection:Ye,block:Ze,formContainer:Je,"--second_form_container":"_--second_form_container_q72vo_148",_description_modal:Qe,"visible-animate":"_visible-animate_q72vo_174",_pie_chart:Ue,_sticky_container:Ke,"--group":"_--group_q72vo_228",heading:Xe,"--field":"_--field_q72vo_243","input-wrapper":"_input-wrapper_q72vo_251","dollar-prefix":"_dollar-prefix_q72vo_256","--label":"_--label_q72vo_279","--error":"_--error_q72vo_333","--interest_rates":"_--interest_rates_q72vo_339",pricing_field:ea,"--purchase_price":"_--purchase_price_q72vo_377","toggle-container":"_toggle-container_q72vo_400","toggle-input":"_toggle-input_q72vo_408",toggle:aa,"toggle-background":"_toggle-background_q72vo_427","toggle-circle-center":"_toggle-circle-center_q72vo_436","toggle-circle":"_toggle-circle_q72vo_436",left:ta,right:na,"toggle-icon":"_toggle-icon_q72vo_467",on:oa,off:ra,submit_button:ia,"--disabled":"_--disabled_q72vo_518",resultContainer:la,"--card":"_--card_q72vo_544",table_view_btn:_a,table_view_btn_1:xa,table_view_btn_2:da,table_view_btn_1_agg:sa,table_view_btn_2_agg:ca,"--activeBtn":"_--activeBtn_q72vo_640",chartContainer:ba,"--chart_group":"_--chart_group_q72vo_666","--chart":"_--chart_q72vo_666","doughnut-wrapper":"_doughnut-wrapper_q72vo_681","doughnut-card":"_doughnut-card_q72vo_690","doughnut-canvas-wrap":"_doughnut-canvas-wrap_q72vo_697",doughnutChart:pa,"dough-legend":"_dough-legend_q72vo_709","legend-item":"_legend-item_q72vo_718","legend-swatch":"_legend-swatch_q72vo_725","legend-label":"_legend-label_q72vo_731","--navigation":"_--navigation_q72vo_737",scheduleContainer:ua,"--year_container":"_--year_container_q72vo_781",tableContainer:va,tableWrapper:fa,"amort-table-container":"_amort-table-container_q72vo_831","amort-table":"_amort-table_q72vo_831","amort-table-footer":"_amort-table-footer_q72vo_871"},ma=$;function de(){const b=["Chart","1645bHWDKh","validateLicense","26826430iKDIcn","getAttribute","script","sba-504-widget","license-key","127442CjJaAc","71292582-1905-0b92a3ef0ff1","License validation failed","https://cdn.jsdelivr.net/npm/chart.js","valid","innerHTML","4745769xxLctn","createElement","shadowRoot","attachShadow","986914WqVjsz","25536yvRnOE","status","2eNkdHU","appendChild","location","5146532MkQIZq","head","async","15644187QWlBgF","style","hostname","368IEcOut"];return de=function(){return b},de()}(function(b,e){const r=$,x=b();for(;;)try{if(parseInt(r(491))/1*(parseInt(r(494))/2)+parseInt(r(487))/3+-parseInt(r(497))/4+-parseInt(r(505))/5*(-parseInt(r(492))/6)+parseInt(r(481))/7*(-parseInt(r(503))/8)+parseInt(r(500))/9+-parseInt(r(507))/10===e)break;x.push(x.shift())}catch{x.push(x.shift())}})(de,900552);function $(b,e){const r=de();return $=function(x,C){return x=x-481,r[x]},$(b,e)}class ha extends HTMLElement{constructor(){const e=$;super(),this[e(490)]({mode:"open"})}async connectedCallback(){const e=$,r=this[e(508)](e(511)),x=this[e(508)]("license-signature");if(!await this[e(506)](r,x)){this.shadowRoot[e(486)]="<p>❌ Unauthorized widget usage</p>";return}if(!window[e(504)]){const R=document[e(488)](e(509));R.src=e(484),R[e(499)]=!0,document[e(498)][e(495)](R)}const v=document[e(488)](e(501));v.textContent=je,this[e(489)][e(495)](v),Fe(this[e(489)],ga),Ne(this.shadowRoot)}async validateLicense(e){var x;const r=$;if(!e)return!1;if(e===r(482))return!0;try{const C=((x=window==null?void 0:window[r(496)])==null?void 0:x[r(502)])||"";return(await(await fetch("https://services.simplifyingcalculation.com/api/license/validate/?license_key="+e,{method:"GET"})).json())[r(493)]===r(485)}catch(C){return console.error(r(483),C),!1}}}customElements.define(ma(510),ha);(function(b,e){for(var r=ge,x=b();;)try{var C=parseInt(r(345))/1*(-parseInt(r(342))/2)+parseInt(r(347))/3+parseInt(r(349))/4*(parseInt(r(344))/5)+parseInt(r(343))/6+-parseInt(r(341))/7+-parseInt(r(348))/8+parseInt(r(350))/9*(-parseInt(r(346))/10);if(C===e)break;x.push(x.shift())}catch{x.push(x.shift())}})(se,498596);function se(){var b=["2150225ozYjVZ","2674iRuAPd","2416632DtCVuX","35rjGfju","93fnVhpz","9770oflCWN","2245212FpLBKp","1680360QmpsFx","143324qMaGWZ","2412GfpvWm"];return se=function(){return b},se()}function ge(b,e){var r=se();return ge=function(x,C){x=x-341;var v=r[x];return v},ge(b,e)}
